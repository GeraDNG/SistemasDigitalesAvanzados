/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/ProgSisDigAva/First_Term_Exam/First_Term_Exam.vhd";
extern char *IEEE_P_2592010699;



static void work_a_1418695556_3212880686_p_0(char *t0)
{
    char t6[16];
    char t11[16];
    char t16[16];
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    char *t7;
    char *t8;
    char *t9;
    unsigned char t10;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(36, ng0);

LAB3:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1352U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t7 = ((IEEE_P_2592010699) + 4024);
    t1 = xsi_base_array_concat(t1, t6, t7, (char)99, t3, (char)99, t5, (char)101);
    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t10 = *((unsigned char *)t9);
    t12 = ((IEEE_P_2592010699) + 4024);
    t8 = xsi_base_array_concat(t8, t11, t12, (char)97, t1, t6, (char)99, t10, (char)101);
    t13 = (t0 + 1032U);
    t14 = *((char **)t13);
    t15 = *((unsigned char *)t14);
    t17 = ((IEEE_P_2592010699) + 4024);
    t13 = xsi_base_array_concat(t13, t16, t17, (char)97, t8, t11, (char)99, t15, (char)101);
    t18 = (1U + 1U);
    t19 = (t18 + 1U);
    t20 = (t19 + 1U);
    t21 = (4U != t20);
    if (t21 == 1)
        goto LAB5;

LAB6:    t22 = (t0 + 3656);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memcpy(t26, t13, 4U);
    xsi_driver_first_trans_fast(t22);

LAB2:    t27 = (t0 + 3560);
    *((int *)t27) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(4U, t20, 0);
    goto LAB6;

}

static void work_a_1418695556_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t4;
    unsigned char t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t28;
    unsigned char t29;
    char *t30;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t40;
    unsigned char t41;
    char *t42;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t52;
    unsigned char t53;
    char *t54;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t76;
    unsigned char t77;
    char *t78;
    char *t80;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    char *t88;
    unsigned char t89;
    char *t90;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;
    char *t100;
    unsigned char t101;
    char *t102;
    char *t104;
    char *t105;
    char *t106;
    char *t107;
    char *t108;
    char *t109;
    char *t110;
    char *t112;
    unsigned char t113;
    char *t114;
    char *t116;
    char *t117;
    char *t118;
    char *t119;
    char *t120;
    char *t121;
    char *t122;
    char *t124;
    unsigned char t125;
    char *t126;
    char *t128;
    char *t129;
    char *t130;
    char *t131;
    char *t132;
    char *t133;
    char *t134;
    char *t136;
    unsigned char t137;
    char *t138;
    char *t140;
    char *t141;
    char *t142;
    char *t143;
    char *t144;
    char *t145;
    char *t146;
    char *t148;
    unsigned char t149;
    char *t150;
    char *t152;
    char *t153;
    char *t154;
    char *t155;
    char *t156;
    char *t157;
    char *t158;
    char *t160;
    unsigned char t161;
    char *t162;
    char *t164;
    char *t165;
    char *t166;
    char *t167;
    char *t168;
    char *t169;
    char *t170;
    char *t172;
    unsigned char t173;
    char *t174;
    char *t176;
    char *t177;
    char *t178;
    char *t179;
    char *t180;
    char *t181;
    char *t183;
    char *t184;
    char *t185;
    char *t186;
    char *t187;
    char *t188;

LAB0:    xsi_set_current_line(37, ng0);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t1 = (t0 + 5588);
    t4 = ((IEEE_P_2592010699) + 4024);
    t5 = xsi_vhdl_lessthanEqual(t4, t2, 4U, t1, 4U);
    if (t5 != 0)
        goto LAB3;

LAB4:    t13 = (t0 + 1832U);
    t14 = *((char **)t13);
    t13 = (t0 + 5602);
    t16 = ((IEEE_P_2592010699) + 4024);
    t17 = xsi_vhdl_lessthanEqual(t16, t14, 4U, t13, 4U);
    if (t17 != 0)
        goto LAB5;

LAB6:    t25 = (t0 + 1832U);
    t26 = *((char **)t25);
    t25 = (t0 + 5616);
    t28 = ((IEEE_P_2592010699) + 4024);
    t29 = xsi_vhdl_lessthanEqual(t28, t26, 4U, t25, 4U);
    if (t29 != 0)
        goto LAB7;

LAB8:    t37 = (t0 + 1832U);
    t38 = *((char **)t37);
    t37 = (t0 + 5630);
    t40 = ((IEEE_P_2592010699) + 4024);
    t41 = xsi_vhdl_lessthanEqual(t40, t38, 4U, t37, 4U);
    if (t41 != 0)
        goto LAB9;

LAB10:    t49 = (t0 + 1832U);
    t50 = *((char **)t49);
    t49 = (t0 + 5644);
    t52 = ((IEEE_P_2592010699) + 4024);
    t53 = xsi_vhdl_lessthanEqual(t52, t50, 4U, t49, 4U);
    if (t53 != 0)
        goto LAB11;

LAB12:    t61 = (t0 + 1832U);
    t62 = *((char **)t61);
    t61 = (t0 + 5658);
    t64 = ((IEEE_P_2592010699) + 4024);
    t65 = xsi_vhdl_lessthanEqual(t64, t62, 4U, t61, 4U);
    if (t65 != 0)
        goto LAB13;

LAB14:    t73 = (t0 + 1832U);
    t74 = *((char **)t73);
    t73 = (t0 + 5672);
    t76 = ((IEEE_P_2592010699) + 4024);
    t77 = xsi_vhdl_lessthanEqual(t76, t74, 4U, t73, 4U);
    if (t77 != 0)
        goto LAB15;

LAB16:    t85 = (t0 + 1832U);
    t86 = *((char **)t85);
    t85 = (t0 + 5686);
    t88 = ((IEEE_P_2592010699) + 4024);
    t89 = xsi_vhdl_lessthanEqual(t88, t86, 4U, t85, 4U);
    if (t89 != 0)
        goto LAB17;

LAB18:    t97 = (t0 + 1832U);
    t98 = *((char **)t97);
    t97 = (t0 + 5700);
    t100 = ((IEEE_P_2592010699) + 4024);
    t101 = xsi_vhdl_lessthanEqual(t100, t98, 4U, t97, 4U);
    if (t101 != 0)
        goto LAB19;

LAB20:    t109 = (t0 + 1832U);
    t110 = *((char **)t109);
    t109 = (t0 + 5714);
    t112 = ((IEEE_P_2592010699) + 4024);
    t113 = xsi_vhdl_lessthanEqual(t112, t110, 4U, t109, 4U);
    if (t113 != 0)
        goto LAB21;

LAB22:    t121 = (t0 + 1832U);
    t122 = *((char **)t121);
    t121 = (t0 + 5728);
    t124 = ((IEEE_P_2592010699) + 4024);
    t125 = xsi_vhdl_lessthanEqual(t124, t122, 4U, t121, 8U);
    if (t125 != 0)
        goto LAB23;

LAB24:    t133 = (t0 + 1832U);
    t134 = *((char **)t133);
    t133 = (t0 + 5746);
    t136 = ((IEEE_P_2592010699) + 4024);
    t137 = xsi_vhdl_lessthanEqual(t136, t134, 4U, t133, 8U);
    if (t137 != 0)
        goto LAB25;

LAB26:    t145 = (t0 + 1832U);
    t146 = *((char **)t145);
    t145 = (t0 + 5764);
    t148 = ((IEEE_P_2592010699) + 4024);
    t149 = xsi_vhdl_lessthanEqual(t148, t146, 4U, t145, 8U);
    if (t149 != 0)
        goto LAB27;

LAB28:    t157 = (t0 + 1832U);
    t158 = *((char **)t157);
    t157 = (t0 + 5782);
    t160 = ((IEEE_P_2592010699) + 4024);
    t161 = xsi_vhdl_lessthanEqual(t160, t158, 4U, t157, 8U);
    if (t161 != 0)
        goto LAB29;

LAB30:    t169 = (t0 + 1832U);
    t170 = *((char **)t169);
    t169 = (t0 + 5800);
    t172 = ((IEEE_P_2592010699) + 4024);
    t173 = xsi_vhdl_lessthanEqual(t172, t170, 4U, t169, 8U);
    if (t173 != 0)
        goto LAB31;

LAB32:
LAB33:    t181 = (t0 + 5818);
    t183 = (t0 + 3720);
    t184 = (t183 + 56U);
    t185 = *((char **)t184);
    t186 = (t185 + 56U);
    t187 = *((char **)t186);
    memcpy(t187, t181, 10U);
    xsi_driver_first_trans_fast_port(t183);

LAB2:    t188 = (t0 + 3576);
    *((int *)t188) = 1;

LAB1:    return;
LAB3:    t6 = (t0 + 5592);
    t8 = (t0 + 3720);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t6, 10U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB2;

LAB5:    t18 = (t0 + 5606);
    t20 = (t0 + 3720);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t18, 10U);
    xsi_driver_first_trans_fast_port(t20);
    goto LAB2;

LAB7:    t30 = (t0 + 5620);
    t32 = (t0 + 3720);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    memcpy(t36, t30, 10U);
    xsi_driver_first_trans_fast_port(t32);
    goto LAB2;

LAB9:    t42 = (t0 + 5634);
    t44 = (t0 + 3720);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    memcpy(t48, t42, 10U);
    xsi_driver_first_trans_fast_port(t44);
    goto LAB2;

LAB11:    t54 = (t0 + 5648);
    t56 = (t0 + 3720);
    t57 = (t56 + 56U);
    t58 = *((char **)t57);
    t59 = (t58 + 56U);
    t60 = *((char **)t59);
    memcpy(t60, t54, 10U);
    xsi_driver_first_trans_fast_port(t56);
    goto LAB2;

LAB13:    t66 = (t0 + 5662);
    t68 = (t0 + 3720);
    t69 = (t68 + 56U);
    t70 = *((char **)t69);
    t71 = (t70 + 56U);
    t72 = *((char **)t71);
    memcpy(t72, t66, 10U);
    xsi_driver_first_trans_fast_port(t68);
    goto LAB2;

LAB15:    t78 = (t0 + 5676);
    t80 = (t0 + 3720);
    t81 = (t80 + 56U);
    t82 = *((char **)t81);
    t83 = (t82 + 56U);
    t84 = *((char **)t83);
    memcpy(t84, t78, 10U);
    xsi_driver_first_trans_fast_port(t80);
    goto LAB2;

LAB17:    t90 = (t0 + 5690);
    t92 = (t0 + 3720);
    t93 = (t92 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    memcpy(t96, t90, 10U);
    xsi_driver_first_trans_fast_port(t92);
    goto LAB2;

LAB19:    t102 = (t0 + 5704);
    t104 = (t0 + 3720);
    t105 = (t104 + 56U);
    t106 = *((char **)t105);
    t107 = (t106 + 56U);
    t108 = *((char **)t107);
    memcpy(t108, t102, 10U);
    xsi_driver_first_trans_fast_port(t104);
    goto LAB2;

LAB21:    t114 = (t0 + 5718);
    t116 = (t0 + 3720);
    t117 = (t116 + 56U);
    t118 = *((char **)t117);
    t119 = (t118 + 56U);
    t120 = *((char **)t119);
    memcpy(t120, t114, 10U);
    xsi_driver_first_trans_fast_port(t116);
    goto LAB2;

LAB23:    t126 = (t0 + 5736);
    t128 = (t0 + 3720);
    t129 = (t128 + 56U);
    t130 = *((char **)t129);
    t131 = (t130 + 56U);
    t132 = *((char **)t131);
    memcpy(t132, t126, 10U);
    xsi_driver_first_trans_fast_port(t128);
    goto LAB2;

LAB25:    t138 = (t0 + 5754);
    t140 = (t0 + 3720);
    t141 = (t140 + 56U);
    t142 = *((char **)t141);
    t143 = (t142 + 56U);
    t144 = *((char **)t143);
    memcpy(t144, t138, 10U);
    xsi_driver_first_trans_fast_port(t140);
    goto LAB2;

LAB27:    t150 = (t0 + 5772);
    t152 = (t0 + 3720);
    t153 = (t152 + 56U);
    t154 = *((char **)t153);
    t155 = (t154 + 56U);
    t156 = *((char **)t155);
    memcpy(t156, t150, 10U);
    xsi_driver_first_trans_fast_port(t152);
    goto LAB2;

LAB29:    t162 = (t0 + 5790);
    t164 = (t0 + 3720);
    t165 = (t164 + 56U);
    t166 = *((char **)t165);
    t167 = (t166 + 56U);
    t168 = *((char **)t167);
    memcpy(t168, t162, 10U);
    xsi_driver_first_trans_fast_port(t164);
    goto LAB2;

LAB31:    t174 = (t0 + 5808);
    t176 = (t0 + 3720);
    t177 = (t176 + 56U);
    t178 = *((char **)t177);
    t179 = (t178 + 56U);
    t180 = *((char **)t179);
    memcpy(t180, t174, 10U);
    xsi_driver_first_trans_fast_port(t176);
    goto LAB2;

LAB34:    goto LAB2;

}


extern void work_a_1418695556_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1418695556_3212880686_p_0,(void *)work_a_1418695556_3212880686_p_1};
	xsi_register_didat("work_a_1418695556_3212880686", "isim/First_Term_Exam_tb_isim_beh.exe.sim/work/a_1418695556_3212880686.didat");
	xsi_register_executes(pe);
}
